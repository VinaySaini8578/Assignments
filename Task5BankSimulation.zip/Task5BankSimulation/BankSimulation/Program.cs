﻿using System;
using System.Collections.Generic;

namespace BankSimulation
{
    internal class BankAccount
    {
        public int AccountNumber { get; private set; }
        public string HolderName { get; private set; }
        public float Balance { get; private set; }

        public BankAccount(string holderName, int accountNumber)
        {
            HolderName = holderName;
            AccountNumber = accountNumber;
            Balance = 25000; // Starting balance
        }

        // Function to deposit money into user's account
        public void Deposit(float amount)
        {
            // Update Balance
            Balance += amount;
            Console.WriteLine($"Deposited {amount} to {HolderName}. New Balance: {Balance}");
        }

        // function to withdraw money from an account
        public void Withdraw(float amount)
        {
            // Validation : Withdrawl amount can't be greater than Balance
            if (amount > Balance)
            {
                Console.WriteLine($"Insufficient funds. Withdrawl failed for {HolderName}.");
                return;
            }
            // Balance updated
            Balance -= amount;
            Console.WriteLine($"Withdrew {amount} from {HolderName}. New Balance: {Balance}");
        }

        public void Transfer(BankAccount recipient, float amount)
        {
            if (amount > Balance)
            {
                Console.WriteLine("Insufficient funds. Transfer failed.");
                return;
            }
            // update balance in both accounts
            Balance -= amount;
            recipient.Balance += amount;
            Console.WriteLine($"Transferred {amount} from {HolderName} to {recipient.HolderName}");
        }

        static void Main(string[] args)
        {
            // List of 5 people with bank accounts
            List<BankAccount> accounts = new List<BankAccount>()
            {
                new BankAccount("Vinay", 111),
                new BankAccount("Vikas", 222),
                new BankAccount("Kishan", 333),
                new BankAccount("Jagriti", 444),
                new BankAccount("Simran", 555)
            };

            // Show initial data of all users
            BankAccount.ShowAllData(accounts);

            // Menu driven operations for transactions
            while (true)
            {
                Console.WriteLine("\n==== Bank Menu ====");
                Console.WriteLine("Enter 1 to Deposit");
                Console.WriteLine("Enter 2 to Withdraw");
                Console.WriteLine("Enter 3 to Transfer");
                Console.WriteLine("Enter 4 to Show All Accounts");
                Console.WriteLine("Enter 5 to Exit");
                Console.Write("Enter your choice: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    // Case 1 to Deposit money into an account
                    case "1":
                        {
                            // getting the account which money is to be deposited into
                            BankAccount acc = GetAccountByNumber(accounts, "Enter your account number: ");
                            if (acc != null)
                            {
                                // function to read Positive values for amount
                                float amount = ReadPositiveFloat("Enter amount to deposit: ");
                                if (amount == -1) // refused by user handled
                                    break;
                                acc.Deposit(amount); // valid amount , then Deposit
                            }
                            break;
                        }

                    case "2":
                        {
                            BankAccount acc = GetAccountByNumber(accounts, "Enter your account number: ");
                            if (acc != null)
                            {
                                // function to read value for amount (repetetive)
                                float amount = ReadPositiveFloat("Enter amount to withdraw: ");
                                if (amount == -1) // Input Refused by user handled
                                    break;
                                acc.Withdraw(amount); // Withdraw valid account
                            }
                            break;
                        }

                    case "3":
                            // Getting sender and receiver account with account number
                            BankAccount sender = GetAccountByNumber(accounts, "Enter your account number: ");
                            if (sender == null) // if sender is null , don't proceed
                                break;
                            BankAccount receiver = GetAccountByNumber(accounts, "Enter recipient account number: ");
                            if (receiver == null)
                                break;
                            // Sender and receiver accounts must not be same
                            if (sender != receiver)
                            {
                                float amount = ReadPositiveFloat("Enter amount to transfer: ");
                                sender.Transfer(receiver, amount);
                            }
                            else
                            {
                                Console.WriteLine("Cannot transfer to the same account.");
                            }
                            break;

                    case "4":
                            BankAccount.ShowAllData(accounts); // Show Balance and all account Holders
                            break;
                    case "5":
                            Console.WriteLine("Exit !");
                            Console.ReadKey();
                            return;
                    default:
                            Console.WriteLine("Invalid choice. Please select a valid option.");
                            break;
                }
            }
        }
        // Function to show all Account Holders and their Balance
        public static void ShowAllData(List<BankAccount> accounts)
        {
            Console.WriteLine("\n-----------------------------");
            Console.WriteLine("{0,-10} | {1,-15}", "Holder Name", "Balance");
            Console.WriteLine("-----------------------------");
            foreach (BankAccount acc in accounts)
            {
                Console.WriteLine("{0,-11} | {1,-15} ", acc.HolderName, acc.Balance);
            }
            Console.WriteLine("-----------------------------\n");
        }

        // Helper method to get account by account number
        static BankAccount GetAccountByNumber(List<BankAccount> accounts, string prompt)
        {
            // custom prompt as 2nd arg 
            Console.Write(prompt);
            if (int.TryParse(Console.ReadLine(), out int accNum))
            {
                foreach (var acc in accounts)
                {
                    if (acc.AccountNumber == accNum)
                    {
                        return acc; // account found
                    }
                }
                Console.WriteLine("Account not found.");
                return null;
            }
            else
            {
                Console.WriteLine("Invalid account number.");
                return null;
            }
        }

        // Helper method to read a Amounts with retry
        static float ReadPositiveFloat(string prompt)
        {
            // Loop to continue asking for amount 
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (float.TryParse(input, out float value))
                {
                    if (value > 0)
                    {
                        return value;
                    }
                    else
                    {
                        Console.WriteLine("Amount must be greater than 0.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input");
                }

                // prompt msg to continue
                Console.Write("Enter Yes to try again : ");
                string retry = Console.ReadLine();
                if (retry == null || (retry.ToLower() != "yes"))
                {
                    Console.WriteLine("Operation cancelled.");
                    return -1; // return -1 if refused by the user 
                }
            }
        }
    }
}
