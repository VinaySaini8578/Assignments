﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7FoodMenu
{
    interface IFoodItem
    {
        string Name { get; set; }
        decimal Price { get; set; }
        FoodCategory Category { get; set; }
    }
}
