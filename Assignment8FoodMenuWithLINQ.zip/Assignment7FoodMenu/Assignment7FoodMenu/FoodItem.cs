﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7FoodMenu
{
    class FoodItem : IFoodItem
    {
        // Food item details
        public string Name { get; set; }
        public decimal Price { get; set; }
        public FoodCategory Category { get; set; } // category for every food item

        public FoodItem(string name, decimal price, FoodCategory category)
        {
            Name = name;
            Price = price;
            Category = category;
        }
    }
}

