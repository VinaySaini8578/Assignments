﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7FoodMenu
{
    interface IOrder
    {
        void AddItem(IFoodItem item, int quantity);
        void RemoveItem(string itemName);
        void CancelOrder();
        decimal GetTotal();
        void DisplayOrderItems();
        bool IsEmpty { get; }
    }
}

