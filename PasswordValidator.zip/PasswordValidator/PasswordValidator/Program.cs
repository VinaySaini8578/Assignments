﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordValidator
{
    internal class Program
    {
        static bool HasValidCharacters(string input)
        {
            int upperCaseCt=0, lowerCaseCt=0, digitCt=0, specialCharCt=0;
            bool result = true;
            foreach(char ch in input)
            {
                if (char.IsLower(ch))
                    lowerCaseCt++;
                else if (char.IsUpper(ch))
                    upperCaseCt++;
                else if (char.IsDigit(ch))
                    digitCt++;
                else
                    specialCharCt++;

                if (lowerCaseCt > 0 && upperCaseCt > 0 && digitCt > 0 && specialCharCt > 0)
                    break;
            }
            if (upperCaseCt == 0 || lowerCaseCt == 0 || digitCt == 0 || specialCharCt == 0)
            {
                Console.Write("\nInvalid Password\nPassword must contain at least : ");
                if (upperCaseCt == 0)
                    Console.Write("1 uppercase-character ");
                if (lowerCaseCt == 0)
                    Console.Write("1 lowercase-character ");
                if (digitCt == 0)
                    Console.Write("1 digit ");
                if (specialCharCt == 0)
                    Console.Write("1 Special-symbol");
                result = false;
            }
                
            return result;
        }
        static string ReadPassword()
        {
            int chances = 5;
            while (chances-- >= 1)
            {
                if(chances == 4)
                    Console.WriteLine("\nEnter the password : ");
                else
                    Console.WriteLine("\n\nEnter the password (Chances left : {0}) : ", chances+1);
                try
                {
                    string input = Console.ReadLine();
                    bool hasNoWhiteSpace = !string.IsNullOrEmpty(input);
                    if(!hasNoWhiteSpace)
                    {
                        Console.WriteLine("\nInvalid Password\nNo white spaces are allowed !");
                        continue;
                    }
                    bool hasValidLength = input.Length >= 8;
                    if(!hasValidLength)
                    {
                        Console.WriteLine("\nInvalid Password\nPassword must be at least 8 characters long !");
                        continue;
                    }
                    bool hasValidCharacters = HasValidCharacters(input);
                    if(!hasValidCharacters)
                    {
                        continue;
                    }
                    return input;
                }
                catch (Exception ex) 
                {
                    Console.WriteLine("\n" + ex.Message);
                }
            }
            Console.WriteLine("\nYou ran out of chances to set Password !");
            return "";
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the password that meets the criteria that follows :\n");
            Console.WriteLine("Password must be at least 8 characters long");
            Console.WriteLine("Password must contain at least \n-> 1 digit\n-> 1 uppercase character\n-> 1 lowercase character\n-> 1 special character");
            string password = ReadPassword();
            if(password != "")
            Console.WriteLine("\nPassword set successfully");
        }
    }
}
