﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7FoodMenu
{
    class OrderItem
    {
        public FoodItem Item { get; set; } // FoodItem class type to store food item 
        public int Quantity { get; set; } // to store ordered quantity

        public OrderItem(FoodItem item, int qty)
        {
            Item = item;
            Quantity = qty;
        }
    }
}

