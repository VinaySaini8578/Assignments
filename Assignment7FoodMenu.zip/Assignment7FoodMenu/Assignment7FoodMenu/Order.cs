﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;

namespace Assignment7FoodMenu
{
    class Order : IOrder
    {
        // list of OrderItem type to store quantity as well
        private List<OrderItem> orderItems = new List<OrderItem>();
        public bool IsEmpty
        {
            get { return orderItems.Count == 0; }
        }
        public void AddItem(IFoodItem item, int quantity)
        {
            FoodItem foodItem = (FoodItem)item;
            OrderItem existing = checkExisting(orderItems, item.Name);

            // Updating the quantity if already exists
            if (existing != null)
            {
                existing.Quantity += quantity;
            }
            // otherwise add the item
            else
            {
                orderItems.Add(new OrderItem(foodItem, quantity));
            }

            Console.WriteLine($"{foodItem.Name} x {quantity} added to your order.");
        }

        public void RemoveItem(string itemName)
        {
            OrderItem existing = checkExisting(orderItems, itemName);

            if (existing == null)
            {
                return;
            }

            orderItems.Remove(existing);
            Console.WriteLine($"{itemName} removed from your order.");
        }

        public void UpdateItemQuantity(string itemName, int newQty)
        {
            OrderItem existing = checkExisting(orderItems, itemName);

            if (existing == null)
            {
                return;
            }
            
            existing.Quantity = newQty;
            Console.WriteLine($"{itemName} quantity updated to {newQty}.");
        }

        public void CancelOrder()
        {
            orderItems.Clear();
            Console.WriteLine("Order cancelled.");
        }

        public decimal GetTotal()
        {
            decimal total = 0;
            foreach (OrderItem oi in orderItems)
            {
                total += oi.Item.Price * oi.Quantity;
            }
            return total;
        }

        public void DisplayOrderItems()
        {
            if (IsEmpty)
            {
                Console.WriteLine("Your order is empty.");
                return;
            }

            Console.WriteLine("\n--- Order Details ---");
            foreach (OrderItem oi in orderItems)
            {
                Console.WriteLine($"{oi.Item.Name} x {oi.Quantity} = Rs.{oi.Item.Price * oi.Quantity}");
            }
            Console.WriteLine($"Total Bill = Rs.{GetTotal()}");
        }

        public List<OrderItem> GetOrderedItems()
        {
            List<OrderItem> orderedItems = new List<OrderItem>();
            foreach (OrderItem oi in orderItems)
            {
                orderedItems.Add(new OrderItem(oi.Item, oi.Quantity));
            }
            return orderedItems;
        }
        static OrderItem checkExisting(List<OrderItem> orderItems, string itemName)
        {
            OrderItem existing = null;
            foreach (OrderItem oi in orderItems)
            {
                if (oi.Item.Name.ToLower() == itemName.ToLower())
                {
                    existing = oi;
                    break;
                }
            }
            return existing;
        }
    }
}
