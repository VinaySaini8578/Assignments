﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7FoodMenu
{
    class FoodItem : IFoodItem
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public FoodCategory Category { get; set; }

        public FoodItem(string name, decimal price, FoodCategory category)
        {
            Name = name;
            Price = price;
            Category = category;
        }
    }
}

