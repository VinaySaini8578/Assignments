﻿using System;
using System.Collections.Generic;
using Assignment7FoodMenu;

namespace Assignment7FoodMenu
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("-- Welcome to the Restaurant --");

            Dictionary<FoodCategory, List<FoodItem>> menu = CreateMenu(); // Dictionary for Menu Creation 
            Order order = new Order(); // single order object to store entire order

            while (true)
            {
                ShowMainMenu();
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        // List (Key) of dictionary passed as arg
                        ShowCategory(menu[FoodCategory.Starter], order);
                        break;
                    case "2":
                        ShowCategory(menu[FoodCategory.Chinese], order);
                        break;
                    case "3":
                        ShowCategory(menu[FoodCategory.MainCourse], order);
                        break;
                    case "4":
                        ShowCategory(menu[FoodCategory.Dessert], order);
                        break;
                    case "5":
                        ShowCategory(menu[FoodCategory.Snacks], order);
                        break;
                    case "6":
                        Checkout(order);
                        break;
                    case "7":
                        Console.WriteLine("Exiting...");
                        Console.ReadKey();
                        return;
                    case "8":
                        if (order.IsEmpty)
                            Console.WriteLine("Nothing to remove.");
                        else
                            RemoveItemFromOrder(order);
                        break;
                    case "9":
                        if (order.IsEmpty)
                            Console.WriteLine("Nothing to update.");
                        else
                            UpdateItemQuantity(order);
                        break;
                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }
            }
        }

        static Dictionary<FoodCategory, List<FoodItem>> CreateMenu()
        {
            return new Dictionary<FoodCategory, List<FoodItem>>
            {
                { FoodCategory.Starter, new List<FoodItem> {
                    new FoodItem("Paneer Tikka", 150, FoodCategory.Starter),
                    new FoodItem("Spring Rolls", 180, FoodCategory.Starter),
                    new FoodItem("French Fries", 130, FoodCategory.Starter)
                }},
                { FoodCategory.Chinese, new List<FoodItem> {
                    new FoodItem("Fried Rice", 100, FoodCategory.Chinese),
                    new FoodItem("Noodles", 120, FoodCategory.Chinese),
                    new FoodItem("Chinese Paneer", 200, FoodCategory.Chinese)
                }},
                { FoodCategory.MainCourse, new List<FoodItem> {
                    new FoodItem("Paneer Butter Masala", 220, FoodCategory.MainCourse),
                    new FoodItem("Dal Makhani", 180, FoodCategory.MainCourse),
                    new FoodItem("Veg Biryani", 200, FoodCategory.MainCourse)
                }},
                { FoodCategory.Dessert, new List<FoodItem> {
                    new FoodItem("Gulab Jamun", 30, FoodCategory.Dessert),
                    new FoodItem("Rasgulla", 30, FoodCategory.Dessert),
                    new FoodItem("Ice Cream", 100, FoodCategory.Dessert)
                }},
                { FoodCategory.Snacks, new List<FoodItem> {
                    new FoodItem("Samosa", 10, FoodCategory.Snacks),
                    new FoodItem("Sandwich", 50, FoodCategory.Snacks),
                    new FoodItem("Pizza", 150, FoodCategory.Snacks)
                }}
            };
        }

        static void ShowMainMenu()
        {
            Console.WriteLine("\nChoose a category:");
            Console.WriteLine("1. Starters");
            Console.WriteLine("2. Chinese");
            Console.WriteLine("3. Main Course");
            Console.WriteLine("4. Desserts");
            Console.WriteLine("5. Snacks");
            Console.WriteLine("6. View Order & Checkout");
            Console.WriteLine("7. Exit");
            Console.WriteLine("8. Remove an item");
            Console.WriteLine("9. Update item quantity");
            Console.Write("Enter choice: ");
        }

        static void ShowCategory(List<FoodItem> items, Order order)
        {
            while (true)
            {
                // showing menu 
                Console.WriteLine("\n--- Menu ---");
                for (int i = 0; i < items.Count; i++)
                    Console.WriteLine($"{i + 1}. {items[i].Name} - Rs.{items[i].Price}");
                Console.WriteLine("0. Back");

                // Loop for input validation
                int choice;
                while (true)
                {
                    Console.Write("Enter dish number to add (0 to go back): ");
                    if (int.TryParse(Console.ReadLine(), out choice) && choice >= 0 && choice <= items.Count)
                        break;
                    Console.WriteLine("Invalid input. Please enter a valid number.");
                }

                if (choice == 0) return;

                // Adding food item into order
                int qty;
                while (true)
                {
                    Console.Write($"Enter quantity for {items[choice - 1].Name}: ");
                    if (int.TryParse(Console.ReadLine(), out qty) && qty > 0)
                        break;
                    Console.WriteLine("Invalid quantity. Enter a positive number.");
                }
                // add this food item with this quantity
                order.AddItem(items[choice - 1], qty);
            }
        }


        static void Checkout(Order order)
        {
            Console.WriteLine("\nYour Order:");
            order.DisplayOrderItems();

            if (order.IsEmpty) return;

            Console.WriteLine("\n1. Confirm and place order");
            Console.WriteLine("2. Cancel order and exit");
            Console.WriteLine("3. Back to main menu");
            Console.Write("Enter choice: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.WriteLine("Order placed successfully!");
                    return;
                case "2":
                    order.CancelOrder();
                    Console.WriteLine("Exiting...");
                    return;
                case "3":
                    break;
                default:
                    Console.WriteLine("Invalid choice.");
                    break;
            }
        }

        static void RemoveItemFromOrder(Order order)
        {
            var orderedItems = order.GetOrderedItems();

            Console.WriteLine("\nYour current order:");
            for (int i = 0; i < orderedItems.Count; i++)
                Console.WriteLine($"{i + 1}. {orderedItems[i].Item.Name} x {orderedItems[i].Quantity}");

            Console.Write("Select the item number to remove (0 to cancel): ");
            if (!int.TryParse(Console.ReadLine(), out int choice) || choice < 0 || choice > orderedItems.Count)
            {
                Console.WriteLine("Invalid choice.");
                return;
            }

            if (choice == 0) return;

            string itemName = orderedItems[choice - 1].Item.Name;
            order.RemoveItem(itemName);
        }

        static void UpdateItemQuantity(Order order)
        {
            var orderedItems = order.GetOrderedItems();

            Console.WriteLine("\nYour current order:");
            for (int i = 0; i < orderedItems.Count; i++)
                Console.WriteLine($"{i + 1}. {orderedItems[i].Item.Name} x {orderedItems[i].Quantity}");

            Console.Write("Select the item number to update (0 to cancel): ");
            if (!int.TryParse(Console.ReadLine(), out int choice) || choice < 0 || choice > orderedItems.Count)
            {
                Console.WriteLine("Invalid choice.");
                return;
            }

            if (choice == 0) return;

            string itemName = orderedItems[choice - 1].Item.Name;

            int newQty;
            while (true)
            {
                Console.Write($"Enter new quantity for {itemName} (0 to remove): ");
                if (int.TryParse(Console.ReadLine(), out newQty) && newQty >= 0)
                    break;
                Console.WriteLine("Invalid quantity. Enter again.");
            }

            order.UpdateItemQuantity(itemName, newQty);
        }
    }
}

