﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConverterCorrected
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // user-input for rupees
            int flag = 1;
            double rupees;
            do
            {
                Console.Write("Enter the amount in Rupees (INR) : ");
                try
                {
                    rupees = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Invalid Input");
                    return;
                }
                const double RsToUSD = 11e-3, RsToEuro = 97e-4, RsToCAD = 16e-3, RsToGBP = 84e-4;
                // amount must be greater than 0
                if (rupees > 0)
                {
                    // Conversions 
                    double USD = rupees * RsToUSD;
                    double Euro = rupees * RsToEuro;
                    double CAD = rupees * RsToCAD;
                    double GBP = rupees * RsToGBP;
                    // Limiting decimal places upto 2
                    Console.WriteLine("Amount in USD  : {0}", (USD));
                    Console.WriteLine("Amount in Euro : {0}", (Euro));
                    Console.WriteLine("Amount in CAD  : {0}", (CAD));
                    Console.WriteLine("Amount in GBP  : {0}", (GBP));
                }
                // Invalid case : negative amount
                else
                {
                    Console.WriteLine("Invalid Amount");
                }
                Console.WriteLine("Press 1 to convert again , any Key to exit otherwise : ");
                try
                {
                    flag = int.Parse(Console.ReadLine());
                }
                catch
                {
                    return;
                }
            } while (flag == 1);
        }
    }
}

// Console.ReadLine() always returns a string, so need to convert it into required DataType
// .Parse method throws an exception if unable to parse the dataType

/* .TryParse method returns a boolean based on success of conversion , 2nd arg required is reference of a variable using "out"
    so that the converted value can be stored ; out does not require any initial value and not necessary to change in the function
*/


