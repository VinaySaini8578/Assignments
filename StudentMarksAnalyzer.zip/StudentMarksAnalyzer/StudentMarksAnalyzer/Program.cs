﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace StudentMarksAnalyzer
{
    internal class StudentGrades
    {
        // Marks 
        private int Mathematics, Science, Computer, English;
        private int Practical;
        private int total;

        // Function for marks input
        void getMarks()
        {
            Console.Write("Enter Marks obtained in Mathematics : ");
            this.Mathematics = ReadMarks();
            Console.Write("Enter Marks obtained in Science : ");
            this.Science = ReadMarks();
            Console.Write("Enter Marks obtained in Computer : ");
            this.Computer = ReadMarks();
            Console.Write("Enter Marks obtained in English : ");
            this.English = ReadMarks();
     
            this.Practical = 0;
            this.total = Mathematics + Science + Computer + English;
        }

        // Helper function for input validation
        int ReadMarks()  // RECURSIVE
        {
            try
            {
                int input = int.Parse(Console.ReadLine());
                if (input < 0 || input > 100)
                {
                    Console.WriteLine("Invalid Marks Range");
                    return ReadMarks(); 
                }
                else
                    return input;
            }
            catch 
            {
                Console.WriteLine("Invalid Input Type");
                return ReadMarks();
            }
        }

        // Practical : Guessing Game
        void GuessGame()
        {
            const int key = 70;
            int practicalMarks = 0;
            Console.WriteLine("\nGuess a number between 1 and 100");
            for (int i = 1; i <= 3; ++i)
            {
                if (i == 3)
                {
                    Console.WriteLine("\nYou failed the Test\n");
                    break;
                }
                Console.WriteLine("Guess {0} of 2 (Max Marks for the guess are {1}) : ", i , 100/i);
                try
                {
                    int guessedValue = int.Parse(Console.ReadLine());
                    if (guessedValue == key)
                    {
                        practicalMarks = 100 / i;
                        Console.WriteLine("Guess Successful ! You got {0} marks\n", practicalMarks);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong Guess\n");
                    }
                }
                catch
                {
                    Console.WriteLine("Invalid input type\n");
                }
            }
            this.Practical = practicalMarks;
            this.total = Practical + Mathematics + Science + English + Computer;
        }

        // Function for showing aggregates only
        void ShowMarks(string name)
        {
            Console.WriteLine("{0,-7} {1,12} {2,10} {3,10} {4,10} {5,12} {6,13}",
                              name, Mathematics, Science, Computer, English, Practical, total);
        }
        static void ShowToppers(StudentGrades Vinay, StudentGrades Vikas, StudentGrades Jagriti, StudentGrades Simran, StudentGrades Kishan)
        {
            // Overall Toppers : 
            int maxMarks = Math.Max(Vinay.total, Math.Max(Vikas.total, Math.Max(Jagriti.total, Math.Max(Simran.total, Kishan.total))));
            OverallToppers(Vinay, Vikas, Jagriti, Simran, Kishan, maxMarks);
            SubjectToppers(Vinay, Vikas, Jagriti, Simran, Kishan);
        }
        static void SubjectToppers(StudentGrades Vinay, StudentGrades Vikas, StudentGrades Jagriti, StudentGrades Simran, StudentGrades Kishan)
        {
            int MathsMaxMarks = Math.Max(Vinay.Mathematics, Math.Max(Vikas.Mathematics, Math.Max(Jagriti.Mathematics, Math.Max(Simran.Mathematics, Kishan.Mathematics))));
            if (Vinay.Mathematics == MathsMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Mathematics", "Vinay", MathsMaxMarks);
            if (Vikas.Mathematics == MathsMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Mathematics", "Vikas", MathsMaxMarks);
            if (Jagriti.Mathematics == MathsMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Mathematics", "Jagriti", MathsMaxMarks);
            if (Simran.Mathematics == MathsMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Mathematics", "Simran", MathsMaxMarks);
            if (Kishan.Mathematics == MathsMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Mathematics", "Kishan", MathsMaxMarks);

            int ScienceMaxMarks = Math.Max(Vinay.Science, Math.Max(Vikas.Science, Math.Max(Jagriti.Science, Math.Max(Simran.Science, Kishan.Science))));
            if (Vinay.Science == ScienceMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Science", "Vinay", ScienceMaxMarks);
            if (Vikas.Science == ScienceMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Science", "Vikas", ScienceMaxMarks);
            if (Jagriti.Science == ScienceMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Science", "Jagriti", ScienceMaxMarks);
            if (Simran.Science == ScienceMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Science", "Simran", ScienceMaxMarks);
            if (Kishan.Science == ScienceMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Science", "Kishan", ScienceMaxMarks);

            int ComputerMaxMarks = Math.Max(Vinay.Computer, Math.Max(Vikas.Computer, Math.Max(Jagriti.Computer, Math.Max(Simran.Computer, Kishan.Computer))));
            if (Vinay.Computer == ComputerMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Computer", "Vinay", ComputerMaxMarks);
            if (Vikas.Computer == ComputerMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Computer", "Vikas", ComputerMaxMarks);
            if (Jagriti.Computer == ComputerMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Computer", "Jagriti", ComputerMaxMarks);
            if (Simran.Computer == ComputerMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Computer", "Simran", ComputerMaxMarks);
            if (Kishan.Computer == ComputerMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Computer", "Kishan", ComputerMaxMarks);

            int EnglishMaxMarks = Math.Max(Vinay.English, Math.Max(Vikas.English, Math.Max(Jagriti.English, Math.Max(Simran.English, Kishan.English))));
            if (Vinay.English == EnglishMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "English", "Vinay", EnglishMaxMarks);
            if (Vikas.English == EnglishMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "English", "Vikas", EnglishMaxMarks);
            if (Jagriti.English == EnglishMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "English", "Jagriti", EnglishMaxMarks);
            if (Simran.English == EnglishMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "English", "Simran", EnglishMaxMarks);
            if (Kishan.English == EnglishMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "English", "Kishan", EnglishMaxMarks);

            int PracticalMaxMarks = Math.Max(Vinay.Practical, Math.Max(Vikas.Practical, Math.Max(Jagriti.Practical, Math.Max(Simran.Practical, Kishan.Practical))));
            if (Vinay.Practical == PracticalMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Practical", "Vinay", PracticalMaxMarks);
            if (Vikas.Practical == PracticalMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Practical", "Vikas", PracticalMaxMarks);
            if (Jagriti.Practical == PracticalMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Practical", "Jagriti", PracticalMaxMarks);
            if (Simran.Practical == PracticalMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Practical", "Simran", PracticalMaxMarks);
            if (Kishan.Practical == PracticalMaxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Practical", "Kishan", PracticalMaxMarks);

        }
        static void OverallToppers(StudentGrades Vinay, StudentGrades Vikas, StudentGrades Jagriti, StudentGrades Simran, StudentGrades Kishan, int maxMarks)
        {
            if (Vinay.total == maxMarks)
                Console.WriteLine("{0,-16}{1, -13}{2}", "Overall", "Vinay", maxMarks);
            if (Vikas.total == maxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Overall", "Vikas", maxMarks);
            if (Jagriti.total == maxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Overall", "Jagriti", maxMarks);
            if (Simran.total == maxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Overall", "Simran", maxMarks);
            if (Kishan.total == maxMarks)
                Console.WriteLine("{0, -16}{1, -13}{2}", "Overall", "Kishan", maxMarks);
        }

        static void Main(string[] args)
        {
            // Marks input 
            Console.WriteLine("Enter marks for Vinay : ");
            StudentGrades Vinay = new StudentGrades();
            Vinay.getMarks();
            Console.WriteLine("\nEnter marks for Vikas : ");
            StudentGrades Vikas = new StudentGrades();
            Vikas.getMarks();
            Console.WriteLine("\nEnter marks for Jagriti : ");
            StudentGrades Jagriti = new StudentGrades();

            Jagriti.getMarks();
            Console.WriteLine("\nEnter marks for Simran : ");
            StudentGrades Simran = new StudentGrades();
            Simran.getMarks();
            Console.WriteLine("\nEnter marks for Kishan : ");
            StudentGrades Kishan = new StudentGrades();
            Kishan.getMarks();

            //// Guess Game
            Console.WriteLine("\n----Practical for Vinay----");
            Vinay.GuessGame();
            Console.WriteLine("\n----Practical for Vikas----");
            Vikas.GuessGame();
            Console.WriteLine("\n----Practical for Jagriti----");
            Jagriti.GuessGame();
            Console.WriteLine("\n----Practical for Simran----");
            Simran.GuessGame();
            Console.WriteLine("\n----Practical for Kishan----");
            Kishan.GuessGame();

            // Calculating Total Marks

            // Showing Final Marks 
            Console.WriteLine("Results : ");
            Console.Write("---------------------------------------------------------------------------------");
            Console.WriteLine("\n{0,-12} {1,12} {2,10} {3,10} {4,10} {5,12} {6,8}",
                  "Student", "Mathematics", "Science", "Computer", "English", "Practical", "Total");

            Vinay.ShowMarks("Vinay");
            Vikas.ShowMarks("Vikas");
            Jagriti.ShowMarks("Jagriti");
            Simran.ShowMarks("Simran");
            Kishan.ShowMarks("Kishan");
            Console.Write("---------------------------------------------------------------------------------");

            // Toppers
            Console.WriteLine("\n\nToppers : ");
            Console.WriteLine("---------------------------------------------------------------------------------");
            Console.WriteLine("{0, -16}{1, -13}{2, -5}", "Criteria", "Name", "Marks");
            ShowToppers(Vinay, Vikas, Jagriti, Simran, Kishan);
            Console.WriteLine("---------------------------------------------------------------------------------\n\n");
        }
    }
}
