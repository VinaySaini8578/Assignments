﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace StudentMarksAnalyzer
{
    internal class StudentGrades
    {
        private string name;
        private int Mathematics, Science, Computer, English;
        private int Practical;
        private int total;

        static int defaultNameCounter = 1;
        public StudentGrades(string name)
        {
            this.name = name;
        }

        // function to input 4 sub marks
        public void GetMarks()
        {
            Console.WriteLine($"\nEnter marks for {name}:\n");

            Console.Write("Mathematics: ");
            this.Mathematics = ReadIntWithLimit(100);

            Console.Write("Science: ");
            this.Science = ReadIntWithLimit(100);

            Console.Write("Computer: ");
            this.Computer = ReadIntWithLimit(100);

            Console.Write("English: ");
            this.English = ReadIntWithLimit(100);

            this.Practical = 0;
            this.total = Mathematics + Science + Computer + English;
        }
        // Practical
        public void PlayGuessGame()
        {
            Random rand = new Random();
            int key = rand.Next(1, 101); // random value [1,101) : closed interval for 2nd arg
            int practicalMarks = 0;

            Console.WriteLine($"\n{name}, guess a number between 1 and 100 (2 tries):");

            for (int i = 1; i <= 3; ++i)
            {
                if(i==3)
                {
                    Console.WriteLine("You failed the Practical !\n");
                    return;
                }
                Console.Write($"Guess {i} (Max Marks: {100 / i}): ");
                try
                {
                    int guess = int.Parse(Console.ReadLine());

                    if (guess == key)
                    {
                        practicalMarks = 100 / i;
                        Console.WriteLine("Correct Guess! You got {0} Marks", practicalMarks);
                        break;
                    }
                    else
                        Console.WriteLine("Wrong Guess.");
                }
                catch
                {
                    Console.WriteLine("Invalid Input.");
                }
            }

            this.Practical = practicalMarks;
            this.total += Practical;
        }

        // helper function to show results
        public void Show()
        {
            Console.WriteLine("{0,-12} {1,12} {2,10} {3,10} {4,10} {5,12} {6,8}",
                name, Mathematics, Science, Computer, English, Practical, total);
        }

        // function for int inouts with Validation
        public static int ReadIntWithLimit(int upperLimit)
        {
            int attempts = 3;
            // loop iterating for 3 chances of input
            while (attempts-- > 0)
            {
                try
                {
                    int val = int.Parse(Console.ReadLine());
                    if (val >= 1 && val <= upperLimit) 
                        return val;

                    Console.WriteLine($"Invalid number\n Attempts left: {attempts}");
                }
                catch
                {
                    Console.WriteLine($"Invalid input\n Attempts left: {attempts}");
                }
            }
            return 0;
        }
        // function to validate name string
        static string ReadValidName()
        {
            const int maxLength = 20;
            int attempts = 3;

            while (attempts-- > 0)
            {
                string input = Console.ReadLine().Trim();

                if (!string.IsNullOrWhiteSpace(input) && input.Length <= maxLength && IsAlphabetOnly(input))
                {
                    return input;
                }
                Console.WriteLine($"Invalid name\n Attempts left: {attempts}");
            }

            string defaultName = $"Student{defaultNameCounter++}";
            Console.WriteLine($"Your name has been set as '{defaultName}'.\n");
            return defaultName;
        }

        // Helper function to check if name has only alphabets and spaces
        private static bool IsAlphabetOnly(string name)
        {
            foreach (char c in name)
            {
                if (!char.IsLetter(c) && c != ' ')
                    return false;
            }
            return true;
        }

        // function for Naming students and creating objects in the list
        public static List<StudentGrades> NameStudents(int totalStudents)
        {
            List<StudentGrades> students = new List<StudentGrades>();

            for (int i = 0; i < totalStudents; i++)
            {
                Console.WriteLine($"Enter name for student #{i + 1}: ");
                string name = ReadValidName(); // Validating the name input
                students.Add(new StudentGrades(name));
            }

            return students;
        }

        // showing aggregate result before announcing toppers
        public static void ShowAll(List<StudentGrades> students)
        {
            Console.WriteLine("\nResults:");
            Console.WriteLine("---------------------------------------------------------------------------------");
            Console.WriteLine("{0,-12} {1,12} {2,10} {3,10} {4,10} {5,12} {6,8}\n",
                "Student", "Mathematics", "Science", "Computer", "English", "Practical", "Total");
            // iterating in the list
            foreach (var student in students)
                student.Show();

            Console.WriteLine("---------------------------------------------------------------------------------");
        }

        public static void ShowToppers(List<StudentGrades> students)
        {
            Console.WriteLine("\n\nToppers:");
            Console.WriteLine("---------------------------------------------------------------------------------");
            Console.WriteLine("{0,-16}{1,-13}{2,-5}\n", "Criteria", "Marks", "Name");


            // Overall Toppers
            int maxTotal = 0;
            foreach (var s in students)
            {
                if (s.total > maxTotal) 
                    maxTotal = s.total;
            }
            if (maxTotal == 0)
                return;
            Console.Write("{0,-16}{1,-13}", "Overall", maxTotal);
            foreach (var s in students)
            {
                if (s.total == maxTotal)
                    Console.Write("{0} ", s.name);
            }
            Console.WriteLine();


            // Subject-wise : using lambdas
            ShowSubjectTopper(students, "Mathematics");
            ShowSubjectTopper(students, "Science");
            ShowSubjectTopper(students, "Computer");
            ShowSubjectTopper(students, "English");
            ShowSubjectTopper(students, "Practical");

            Console.WriteLine("---------------------------------------------------------------------------------\n");
        }

        // iterating only over the required subject marks
        static void ShowSubjectTopper(List<StudentGrades> students, string subject)
        {
            int max = 0;

            // find Max for the subject
            foreach (var s in students)
            {
                int marks = 0;

                if (subject == "Mathematics")
                    marks = s.Mathematics;
                else if (subject == "Science")
                    marks = s.Science;
                else if (subject == "Computer")
                    marks = s.Computer;
                else if (subject == "English")
                    marks = s.English;
                else if (subject == "Practical")
                    marks = s.Practical;

                max = Math.Max(max, marks);
            }
            if (max == 0)
                return;

            Console.Write("{0,-16}{1,-13}", subject, max);

            foreach (var s in students)
            {
                int marks = 0;

                if (subject == "Mathematics")
                    marks = s.Mathematics;
                else if (subject == "Science")
                    marks = s.Science;
                else if (subject == "Computer")
                    marks = s.Computer;
                else if (subject == "English")
                    marks = s.English;
                else if (subject == "Practical")
                    marks = s.Practical;

                if (marks == max)
                    Console.Write("{0} ", s.name);
            }

            Console.WriteLine();
        }


        static void Main(string[] args)
        {
            // students strength input
            Console.Write("Enter total number of students (max 100): ");
            int count = ReadIntWithLimit(100);
            // no students
            if (count == 0)
            {
                Console.WriteLine("No students to process.");
                return;
            }
            // list creation
            var students = NameStudents(count);

            // marks input
            foreach (var s in students)
                s.GetMarks();

            // Practical
            foreach (var s in students)
                s.PlayGuessGame();

            // Results Declaration
            ShowAll(students);
            ShowToppers(students);
        }
    }

}
